package softuni.exam.models.entity;

public enum BookGenre {
    CLASSIC_LITERATURE, SCIENCE_FICTION, FANTASY;
}
