package softuni.exam.models.entity;

public enum StatusType {
    unemployed, employed, freelancer

//    UNEMPLOYED, EMPLOYED, FREELANCER;
//    @Override
//    public String toString() {
//        return this.name().toLowerCase();
//    }
}
