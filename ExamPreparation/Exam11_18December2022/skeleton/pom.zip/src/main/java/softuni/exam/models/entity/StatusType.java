package softuni.exam.models.entity;

public enum StatusType {
    UNEMPLOYED, EMPLOYED, FREELANCER
}
